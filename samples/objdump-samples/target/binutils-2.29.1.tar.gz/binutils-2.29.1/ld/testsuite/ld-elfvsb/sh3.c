int main_hidden_data = 1;

int
main_hidden_func ()
{
  return 1;
}
