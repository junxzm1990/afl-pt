#include <stdio.h>

void
property (void)
{
  printf ("PASS\n");
}
