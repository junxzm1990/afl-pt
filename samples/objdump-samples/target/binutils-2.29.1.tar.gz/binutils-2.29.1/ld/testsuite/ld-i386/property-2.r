#...
Displaying notes found in: .note.gnu.property
  Owner                 Data size	Description
  GNU                  0x[0-9a-f]+	NT_GNU_PROPERTY_TYPE_0
      Properties: stack size: 0x800000

#pass
