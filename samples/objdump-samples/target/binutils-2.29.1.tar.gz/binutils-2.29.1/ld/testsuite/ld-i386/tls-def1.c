__thread int gd = 1;
