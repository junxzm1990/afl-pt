#include <stdio.h>

void
foo (void)
{
  printf ("%s\n", __FUNCTION__);
}
