#include <stdlib.h>

void
myexit (int status)
{
  exit (status);
}
