extern void check (void);

int
main ()
{
  check ();
  return 0;
}
