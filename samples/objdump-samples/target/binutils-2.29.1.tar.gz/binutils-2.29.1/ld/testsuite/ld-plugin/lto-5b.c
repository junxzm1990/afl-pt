#include <stdio.h>

void foo(void)
{
  printf ("hello foo\n");
}
