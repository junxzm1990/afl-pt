struct Foooo {
  virtual ~Foooo () { }
};

int main(void)
{
  Foooo t;
  return 0;
}
