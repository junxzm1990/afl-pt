int i;

int bar(void)
{
  return 0x1234;
}
