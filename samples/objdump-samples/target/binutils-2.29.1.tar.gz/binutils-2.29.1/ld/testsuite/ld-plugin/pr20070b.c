/* The first line of this file must match the expectation of
   onall_symbols_read in testplug4.c and the size of this file
   must match the expectation of onclaim_file in testplug4.c.  */

extern int retval;

int func (void)
{
  return retval;
}
