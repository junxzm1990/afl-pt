#include <stdio.h>
#include "pr12942a.h"

test_t b(void)
{
  return test;
}
