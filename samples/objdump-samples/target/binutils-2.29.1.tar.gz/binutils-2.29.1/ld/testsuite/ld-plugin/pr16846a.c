extern int bar (void);

int
main () 
{
  return bar ();
}
