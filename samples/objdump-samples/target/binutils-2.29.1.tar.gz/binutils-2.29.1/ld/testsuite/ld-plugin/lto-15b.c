extern void abort (void);
unsigned long long
__udivdi3(unsigned long long n, unsigned long long d)
{
  abort ();
  return n + d;
}
