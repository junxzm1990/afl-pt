extern void foo(void);
extern void bar(void);

int main(void)
{
  foo();
  bar();
  return 0;
}
