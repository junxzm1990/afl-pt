#include <stdio.h>

void bar(void)
{
  printf ("hello bar\n");
}
