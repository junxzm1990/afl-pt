unsigned long long bar (unsigned long long y)
{
  return 30 / y;
}
