extern void dead ();

void live()
{
  dead ();
}
