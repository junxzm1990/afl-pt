extern int x;

void foobar (void) { x--; }
