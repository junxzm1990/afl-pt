void dead()
{
}
