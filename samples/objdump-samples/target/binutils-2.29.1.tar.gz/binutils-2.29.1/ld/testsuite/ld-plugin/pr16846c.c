__thread int foo;
