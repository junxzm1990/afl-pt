extern int xxx;

int
main ()
{ 
  return xxx;
}
