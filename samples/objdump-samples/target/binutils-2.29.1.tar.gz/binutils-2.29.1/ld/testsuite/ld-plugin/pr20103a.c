void live();

int
main ()
{
    live();
    return 0;
}
