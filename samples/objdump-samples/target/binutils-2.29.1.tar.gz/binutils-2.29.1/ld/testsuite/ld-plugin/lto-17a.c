void
bar (void)
{
}
