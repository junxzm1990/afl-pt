#include <stdio.h>

void
bar (void)
{
  printf ("bar\n");
}
