extern void x (void);

void
y (void)
{
  x ();
}
