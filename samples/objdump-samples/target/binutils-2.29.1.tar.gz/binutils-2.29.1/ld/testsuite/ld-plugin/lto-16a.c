void foo (void) { }
