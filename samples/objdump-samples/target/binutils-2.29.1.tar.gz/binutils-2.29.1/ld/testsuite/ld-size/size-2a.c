__thread char bar[10] __attribute__ ((visibility("hidden")));
