int deallocate_foo;

int *
foo ()
{
  return &deallocate_foo;
}
