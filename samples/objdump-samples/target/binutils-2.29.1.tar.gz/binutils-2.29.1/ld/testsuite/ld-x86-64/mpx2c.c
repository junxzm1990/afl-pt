extern void foo1 (void);
extern void foo2 (void);

int
main (void)
{
  foo1 ();
  foo2 ();
  return 0;
}
