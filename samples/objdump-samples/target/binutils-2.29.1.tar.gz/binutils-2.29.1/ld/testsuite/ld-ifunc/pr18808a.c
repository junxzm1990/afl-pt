#include <stdio.h>

void bar(void);
int main(void)
{
  bar();
  printf("OK\n");
  return 0;
}
