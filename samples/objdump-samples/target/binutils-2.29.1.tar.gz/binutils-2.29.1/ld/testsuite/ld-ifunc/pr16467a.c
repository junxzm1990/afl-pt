const char * 
sd_get_seats(void)
{
  return "OK";
}
