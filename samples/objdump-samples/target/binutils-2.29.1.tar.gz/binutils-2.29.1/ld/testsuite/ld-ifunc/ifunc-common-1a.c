#include <stdio.h>

int foo;
int
main ()
{
  printf ("PASSED: %d\n", foo);
  return 0;
}
