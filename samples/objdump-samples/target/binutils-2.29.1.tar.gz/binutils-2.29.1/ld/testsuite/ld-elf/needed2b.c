extern void pam_end (void);
void pam_end (void) {}
