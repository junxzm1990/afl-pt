extern void foo (void);
extern void bar (void);

int
main ()
{
  foo ();
  bar ();
  return 0;
}
