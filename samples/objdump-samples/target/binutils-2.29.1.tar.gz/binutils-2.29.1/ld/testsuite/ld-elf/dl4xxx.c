#include <stdio.h>

void
xxx1 (void)
{
  printf ("DSO1\n");
}

void
xxx2 (void)
{
  printf ("DSO2\n");
}
