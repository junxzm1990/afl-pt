void
rdynamic ()
{
}

int
main ()
{
  return 0;
}
