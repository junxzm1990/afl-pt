extern void pam_end (void);
void dumpme (void)
{
  pam_end ();
}
