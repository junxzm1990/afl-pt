void
dynamic ()
{
}

int
main ()
{
  return 0;
}
