#include <stdio.h>
void 
a (void)
{
  printf("PASS\n");
}
