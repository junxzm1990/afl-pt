extern void bar (void);
extern void foo (void);

int
main (void)
{
  foo ();
  bar ();
  return 0;
}
