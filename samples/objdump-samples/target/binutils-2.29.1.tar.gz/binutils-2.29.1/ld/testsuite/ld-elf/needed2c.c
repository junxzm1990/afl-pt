extern void dumpme (void);
int main (void)
{
  dumpme();
  return 0;
}
