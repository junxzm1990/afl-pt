extern int eight (void);

int
main (void)
{
  return eight () - 8;
}
