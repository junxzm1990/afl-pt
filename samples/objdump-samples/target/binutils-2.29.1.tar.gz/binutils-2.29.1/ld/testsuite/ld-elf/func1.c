void foo (void) { }
void bar (void) { }
