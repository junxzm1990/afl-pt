void sd_get_seats (void);
void call_sd_get_seats (void)
{
  sd_get_seats ();
}
