#include "dwarf1.h"

struct foo_s foo;

int
main (void)
{
  doprintf ();
  return 0;
}
