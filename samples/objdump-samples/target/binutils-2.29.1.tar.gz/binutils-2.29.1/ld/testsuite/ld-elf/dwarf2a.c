int global_var = 3;
int other_var = 4;

int
function (void)
{
  return 0;
}
