extern void par (void);

int
main (void)
{
  par ();
  return 0;
}
