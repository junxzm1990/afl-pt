int
fun (void)
{
  return 20;
}
