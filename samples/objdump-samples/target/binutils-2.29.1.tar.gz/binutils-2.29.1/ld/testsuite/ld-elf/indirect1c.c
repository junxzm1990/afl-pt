extern void foo (void);

void
bar (void)
{
  foo ();
}
