#include <stdio.h>

void
xxx (void)
{
  printf ("DSO\n");
}
