extern void a (void);
void
b (void)
{
  a();
}
