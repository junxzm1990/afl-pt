#include <stdio.h>

void par (void)
{
  printf ("par\n");
}
