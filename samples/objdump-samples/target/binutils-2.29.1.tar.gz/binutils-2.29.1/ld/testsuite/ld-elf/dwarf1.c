#include <stdio.h>
#include "dwarf1.h"

struct foo_s foo;

void
doprintf (void)
{
  printf ("OK\n");
}
