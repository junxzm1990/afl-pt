#include <stdio.h>

void
bar (void)
{
  printf ("OK\n");
}
