struct A
{
  int i;
  A (int i): i(i) {}
};
